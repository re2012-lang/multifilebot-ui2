import React, { useState, useCallback } from 'react';
// FIX: Import Spinner component from `./icons`.
import { UploadIcon, Spinner } from './icons';

interface FileUploadProps {
  onFileSelect: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, accept, multiple = false }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDrag = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true);
    } else if (e.type === "dragleave") {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileSelect(Array.from(e.dataTransfer.files));
    }
  }, [onFileSelect]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelect(Array.from(e.target.files));
    }
  };

  return (
    <div
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      className={`relative flex flex-col items-center justify-center w-full p-8 border-2 border-dashed rounded-lg transition-colors duration-300 ${isDragging ? 'border-indigo-400 bg-gray-700' : 'border-gray-600 hover:border-gray-500'}`}
    >
      <UploadIcon className="w-12 h-12 text-gray-400 mb-4" />
      <p className="text-gray-400">
        Drag & drop files here, or{' '}
        <label htmlFor="file-upload" className="font-medium text-indigo-400 hover:text-indigo-300 cursor-pointer">
          browse
        </label>
      </p>
      <input id="file-upload" name="file-upload" type="file" className="sr-only" accept={accept} multiple={multiple} onChange={handleChange} />
    </div>
  );
};

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    children: React.ReactNode;
    isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ children, isLoading, ...props }) => {
  return (
    <button
      {...props}
      disabled={isLoading || props.disabled}
      className={`w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors duration-300 ${props.className || ''}`}
    >
      {isLoading ? <Spinner className="w-5 h-5" /> : children}
    </button>
  );
};

export const TextInput = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>((props, ref) => {
    return (
        <input
            {...props}
            ref={ref}
            className={`w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-300 ${props.className || ''}`}
        />
    );
});
TextInput.displayName = 'TextInput';

export const ToolContainer: React.FC<{title: string, description: string, children: React.ReactNode}> = ({ title, description, children }) => {
  return (
    <div className="w-full h-full p-4 sm:p-6 lg:p-8 flex flex-col text-gray-100 bg-gray-800 rounded-2xl shadow-2xl">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">{title}</h1>
        <p className="text-sm sm:text-base text-gray-400 mt-1">{description}</p>
      </div>
      <div className="flex-grow flex flex-col space-y-6">
          {children}
      </div>
    </div>
  )
}