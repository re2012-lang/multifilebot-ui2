
import React, { useState, useEffect } from 'react';
import { FileUpload, Button, TextInput, ToolContainer } from './shared';
import { DownloadIcon, Spinner } from './icons';

// A helper function to simulate processing time
const simulateProcessing = <T,>(result: T, duration: number = 2000): Promise<T> => {
    return new Promise(resolve => {
        setTimeout(() => resolve(result), duration);
    });
};

const fileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const ResultDisplay: React.FC<{ result: any; toolName: string }> = ({ result, toolName }) => {
    if (!result) return null;

    if (Array.isArray(result)) {
        return (
            <div className="w-full bg-gray-900 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Extracted Files:</h3>
                <ul className="space-y-2">
                    {result.map((item, index) => (
                        <li key={index} className="flex justify-between items-center p-2 bg-gray-800 rounded">
                            <span>{item.name}</span>
                            <span className="text-gray-400 text-sm">{item.size}</span>
                        </li>
                    ))}
                </ul>
            </div>
        );
    }

    return (
        <div className="w-full bg-gray-900 p-4 rounded-lg flex items-center space-x-4">
            <DownloadIcon className="w-8 h-8 text-green-400" />
            <div>
                <h3 className="font-semibold">Processing Complete!</h3>
                <a href={result.url} download={result.name} className="text-indigo-400 hover:underline">
                    Download {result.name}
                </a>
            </div>
        </div>
    );
};


export const ArchiveTool: React.FC = () => {
    const [files, setFiles] = useState<File[]>([]);
    const [password, setPassword] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [result, setResult] = useState<any>(null);

    const handleExtract = async () => {
        if (files.length === 0) return;
        setIsProcessing(true);
        setResult(null);
        const simResult = await simulateProcessing([
            { name: 'document.pdf', size: '1.2 MB' },
            { name: 'photo.jpg', size: '3.4 MB' },
            { name: 'archive-nested.zip', size: '5.6 MB' },
        ]);
        setResult(simResult);
        setIsProcessing(false);
    };

    const handleCompress = async () => {
        if (files.length === 0) return;
        setIsProcessing(true);
        setResult(null);
        const simResult = await simulateProcessing({
            name: 'compressed_archive.zip',
            url: '#',
        });
        setResult(simResult);
        setIsProcessing(false);
    };

    return (
        <ToolContainer title="Archive Tool" description="Extract RAR/ZIP archives or compress multiple files into a single ZIP file.">
            <FileUpload onFileSelect={setFiles} accept=".zip,.rar" multiple />
            {files.length > 0 && (
                <div className="bg-gray-900 p-3 rounded-lg">
                    <p className="font-semibold mb-1">Selected files:</p>
                    <ul className="text-sm text-gray-300 list-disc list-inside">
                        {files.map(f => <li key={f.name}>{f.name} ({Math.round(f.size / 1024)} KB)</li>)}
                    </ul>
                </div>
            )}
            <TextInput type="password" placeholder="Archive Password (optional)" value={password} onChange={e => setPassword(e.target.value)} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Button onClick={handleExtract} disabled={files.length === 0} isLoading={isProcessing}>Extract</Button>
                <Button onClick={handleCompress} disabled={files.length === 0} isLoading={isProcessing}>Compress</Button>
            </div>
            {isProcessing && <div className="flex justify-center items-center"><Spinner className="w-8 h-8" /><p className="ml-2">Processing...</p></div>}
            {result && <ResultDisplay result={result} toolName="Archive" />}
        </ToolContainer>
    );
};

export const PdfConversionTool: React.FC = () => {
    const [files, setFiles] = useState<File[]>([]);
    const [previews, setPreviews] = useState<string[]>([]);
    const [isProcessing, setIsProcessing] = useState(false);
    const [result, setResult] = useState<any>(null);

    useEffect(() => {
        if (files.length > 0 && files.every(f => f.type.startsWith('image/'))) {
            Promise.all(files.map(fileToDataURL)).then(setPreviews);
        } else {
            setPreviews([]);
        }
    }, [files]);
    
    const handleConvert = async () => {
        if (files.length === 0) return;
        setIsProcessing(true);
        setResult(null);
        const simResult = await simulateProcessing({
            name: 'converted_document.pdf',
            url: '#',
        }, 2500);
        setResult(simResult);
        setIsProcessing(false);
    };

    return (
        <ToolContainer title="Image to PDF Converter" description="Convert one or more images (JPG, PNG) into a single PDF document.">
            <FileUpload onFileSelect={setFiles} accept="image/jpeg,image/png" multiple />
            {previews.length > 0 && (
                 <div className="bg-gray-900 p-3 rounded-lg">
                    <p className="font-semibold mb-2">{previews.length} image(s) selected:</p>
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                        {previews.map((src, index) => <img key={index} src={src} alt={`preview ${index}`} className="w-full h-20 object-cover rounded"/>)}
                    </div>
                </div>
            )}
            <Button onClick={handleConvert} disabled={files.length === 0} isLoading={isProcessing}>Convert to PDF</Button>
            {isProcessing && <div className="flex justify-center items-center"><Spinner className="w-8 h-8" /><p className="ml-2">Converting...</p></div>}
            {result && <ResultDisplay result={result} toolName="PDF" />}
        </ToolContainer>
    );
};

export const PdfToImageTool: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [result, setResult] = useState<any>(null);

    const handleConvert = async () => {
        if (!file) return;
        setIsProcessing(true);
        setResult(null);
        const simResult = await simulateProcessing({ name: 'converted_images.zip', url: '#' }, 3000);
        setResult(simResult);
        setIsProcessing(false);
    }

    return (
        <ToolContainer title="PDF to Image Converter" description="Convert each page of a PDF file into separate PNG images.">
            <FileUpload onFileSelect={(files) => setFile(files[0])} accept=".pdf" />
            {file && <p className="text-center text-gray-300">Selected: {file.name}</p>}
            <Button onClick={handleConvert} disabled={!file} isLoading={isProcessing}>Convert to Images</Button>
            {isProcessing && <div className="flex justify-center items-center"><Spinner className="w-8 h-8" /><p className="ml-2">Converting...</p></div>}
            {result && <ResultDisplay result={result} toolName="PDF to Image"/>}
        </ToolContainer>
    )
}

export const SecurityTool: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);
    const [password, setPassword] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [result, setResult] = useState<any>(null);

    const handleAction = async (action: 'encrypt' | 'decrypt') => {
        if (!file || !password) return;
        setIsProcessing(true);
        setResult(null);
        const simResult = await simulateProcessing({
            name: `${action}ed_${file.name}`,
            url: '#',
        });
        setResult(simResult);
        setIsProcessing(false);
    };

    return (
        <ToolContainer title="File Encrypter/Decrypter" description="Secure your PDF and ZIP files with a password, or remove existing password protection.">
            <FileUpload onFileSelect={(files) => setFile(files[0])} accept=".zip,.pdf" />
             {file && <p className="text-center text-gray-300">Selected: {file.name}</p>}
            <TextInput type="password" placeholder="Enter Password" value={password} onChange={e => setPassword(e.target.value)} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Button onClick={() => handleAction('encrypt')} disabled={!file || !password} isLoading={isProcessing}>Encrypt</Button>
                <Button onClick={() => handleAction('decrypt')} disabled={!file || !password} isLoading={isProcessing}>Decrypt</Button>
            </div>
            {isProcessing && <div className="flex justify-center items-center"><Spinner className="w-8 h-8" /><p className="ml-2">Processing...</p></div>}
            {result && <ResultDisplay result={result} toolName="Security" />}
        </ToolContainer>
    );
};

export const PasswordCrackerTool: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [progress, setProgress] = useState(0);
    const [result, setResult] = useState<string | null>(null);

    useEffect(() => {
        let interval: number;
        if (isProcessing) {
            interval = window.setInterval(() => {
                setProgress(prev => {
                    if (prev >= 100) {
                        clearInterval(interval);
                        setIsProcessing(false);
                        setResult('password123');
                        return 100;
                    }
                    return prev + Math.random() * 5;
                });
            }, 200);
        }
        return () => clearInterval(interval);
    }, [isProcessing]);
    
    const handleCrack = () => {
        if (!file) return;
        setIsProcessing(true);
        setProgress(0);
        setResult(null);
    };

    return (
        <ToolContainer title="Password Recovery" description="Attempt to recover passwords for your own RAR, ZIP, or PDF files.">
            <div className="p-4 bg-yellow-900/50 border-l-4 border-yellow-400 text-yellow-200 rounded-r-lg">
                <p className="font-bold">Ethical Warning!</p>
                <p className="text-sm">This tool is for educational purposes and for recovering passwords on your own files only. Cracking strong, unknown passwords is computationally infeasible and may be illegal.</p>
            </div>
            <FileUpload onFileSelect={(files) => setFile(files[0])} accept=".zip,.rar,.pdf" />
             {file && <p className="text-center text-gray-300">Selected: {file.name}</p>}
            <Button onClick={handleCrack} disabled={!file} isLoading={isProcessing}>Start Recovery</Button>
            {isProcessing && (
                <div className="w-full">
                    <p className="text-center mb-2">Attempting recovery...</p>
                    <div className="w-full bg-gray-700 rounded-full h-2.5">
                        <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
            )}
            {result && (
                <div className="w-full bg-gray-900 p-4 rounded-lg text-center">
                    <h3 className="font-semibold text-green-400">Password Found!</h3>
                    <p className="font-mono text-lg bg-gray-800 inline-block px-4 py-1 rounded mt-2">{result}</p>
                </div>
            )}
        </ToolContainer>
    );
};


export const VideoDownloaderTool: React.FC = () => {
    const [url, setUrl] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [result, setResult] = useState<any>(null);

    const handleDownload = async () => {
        if (!url) return;
        setIsProcessing(true);
        setResult(null);
        const simResult = await simulateProcessing({
            title: 'Cool Example Video Title',
            thumbnail: 'https://picsum.photos/400/225',
            url: '#',
            size: '42.5 MB'
        });
        setResult(simResult);
        setIsProcessing(false);
    };

    return (
        <ToolContainer title="Video Downloader" description="Download videos from public YouTube and Instagram links.">
            <TextInput type="url" placeholder="Enter YouTube or Instagram URL" value={url} onChange={e => setUrl(e.target.value)} />
            <Button onClick={handleDownload} disabled={!url} isLoading={isProcessing}>Download Video</Button>
            {isProcessing && <div className="flex justify-center items-center"><Spinner className="w-8 h-8" /><p className="ml-2">Fetching video...</p></div>}
            {result && (
                <div className="w-full bg-gray-900 p-4 rounded-lg flex flex-col sm:flex-row items-center gap-4">
                    <img src={result.thumbnail} alt={result.title} className="w-full sm:w-40 rounded-lg"/>
                    <div className="flex-grow">
                        <h3 className="font-semibold">{result.title}</h3>
                        <p className="text-sm text-gray-400">Size: {result.size}</p>
                        <a href={result.url} download className="mt-2 inline-block px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                            Download Now
                        </a>
                    </div>
                </div>
            )}
        </ToolContainer>
    );
};
