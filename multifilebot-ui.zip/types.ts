
export enum Tool {
  ARCHIVE = 'Archive',
  CONVERT_PDF = 'Convert to PDF',
  PDF_TO_IMAGE = 'PDF to Image',
  ENCRYPT_DECRYPT = 'Encrypt/Decrypt',
  PASSWORD_CRACKER = 'Password Cracker',
  VIDEO_DOWNLOADER = 'Video Downloader',
}
