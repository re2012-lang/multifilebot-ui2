
import React, { useState } from 'react';
import { Tool } from './types';
import { ArchiveIcon, PdfIcon, ImageFileIcon, LockIcon, KeyIcon, VideoIcon } from './components/icons';
import { ArchiveTool, PdfConversionTool, PdfToImageTool, SecurityTool, PasswordCrackerTool, VideoDownloaderTool } from './components/ToolPages';

const toolConfig = [
  { id: Tool.ARCHIVE, icon: ArchiveIcon, component: ArchiveTool },
  { id: Tool.CONVERT_PDF, icon: PdfIcon, component: PdfConversionTool },
  { id: Tool.PDF_TO_IMAGE, icon: ImageFileIcon, component: PdfToImageTool },
  { id: Tool.ENCRYPT_DECRYPT, icon: LockIcon, component: SecurityTool },
  { id: Tool.PASSWORD_CRACKER, icon: KeyIcon, component: PasswordCrackerTool },
  { id: Tool.VIDEO_DOWNLOADER, icon: VideoIcon, component: VideoDownloaderTool },
];

const Sidebar: React.FC<{ activeTool: Tool; onSelectTool: (tool: Tool) => void }> = ({ activeTool, onSelectTool }) => {
  return (
    <nav className="flex flex-col items-center space-y-2 bg-gray-900/80 backdrop-blur-sm p-2 sm:p-4 rounded-full border border-gray-700">
      {toolConfig.map(({ id, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onSelectTool(id)}
          className={`relative group flex items-center justify-center w-12 h-12 rounded-full transition-all duration-300
            ${activeTool === id ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'}
          `}
          aria-label={id}
        >
          <Icon className="w-6 h-6" />
          <span className="absolute left-full ml-4 px-2 py-1 bg-gray-800 text-white text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
            {id}
          </span>
        </button>
      ))}
    </nav>
  );
};

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<Tool>(Tool.ARCHIVE);

  const renderTool = () => {
    const tool = toolConfig.find(t => t.id === activeTool);
    if (tool) {
      const ToolComponent = tool.component;
      return <ToolComponent />;
    }
    return null;
  };

  return (
    <div className="min-h-screen w-full bg-gray-900 flex flex-col sm:flex-row items-start p-4 gap-4">
      <header className="w-full sm:w-auto">
        <div className="sm:sticky sm:top-4">
          <Sidebar activeTool={activeTool} onSelectTool={setActiveTool} />
        </div>
      </header>
      <main className="flex-grow w-full h-full">
        <div className="w-full max-w-4xl mx-auto">
          {renderTool()}
        </div>
      </main>
    </div>
  );
};

export default App;
